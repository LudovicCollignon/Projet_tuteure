<?php $__env->startSection('contenu'); ?>
  <ul>
    <li><?php echo $bonneReponse ; ?> </li>
    <li><?php echo $reponseUtilisateur ; ?> </li>
  </ul>

    <?php
      if($bonneReponse == $reponseUtilisateur)
        echo "bravo" ;
      else
        echo "0";
    ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>