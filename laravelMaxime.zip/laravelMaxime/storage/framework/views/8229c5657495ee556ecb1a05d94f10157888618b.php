<?php $__env->startSection('contenu'); ?>
  <div id="enonce">
    quel mot clé est utilisée pour CREER une table petit autiste ?
  </div>

  <div id="reponses">
    <form action="testQCM" method="post">
      <?php echo csrf_field(); ?>
      <input type="radio" name="reponse" value="INSERT">INSERT
      <input type="radio" name="reponse" value="CREATE">CREATE
      <input type="radio" name="reponse" value="DELETE">DELETE<br>
      <input type="submit" name="valider">
    </form>
  </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>