<?php
namespace App ;
use Illuminate\Database\Eloquent\Model;

class reponse_qcms extends Model {

}
 ?>
