<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// ACCUEIL
Route::view('/','accueil');
Route::view('/accueil','accueil');


// CONNEXION - INSCRIPTION
Route::get('/inscription', 'InscriptionController@afficherFormulaire');
Route::post('/inscription', 'InscriptionController@traiterFormulaire');

Route::get('/connexion', 'ConnexionController@afficherFormulaire');
Route::post('/connexion', 'ConnexionController@traiterFormulaire');

// COURS
Route::view('/menu-cours','menu-cours');
Route::view('/modele-cours','modele-cours');
Route::get('/modele-cours{titre}','MenuCoursController@show')->name('modele-cours');


// EXERCICES
Route::view('/menu-exercice','menu-exercice');

// requetes completes
Route::get('/modele-requete.{idDom}.{idEx}','ExerciceRequeteController@show')->name('modele-requete');
Route::post('/modele-requete.{idDom}.{idEx}','ExerciceRequeteController@validation')->name('modele-requete');
Route::post('/exec-exercice-requete.{idDom}.{idEx}','ExerciceRequeteController@exec')->name('exec-exercice-requete');

// texte à trous
Route::get('/modele-texte-a-trous.{idChap}.{idQuest}','ExerciceTatController@show')->name('modele-texte-a-trous');
Route::post('/modele-texte-a-trous', 'ExerciceTatController@verif');

// QCM
Route::get('/modele-qcm.{idDom}.{idEx}','QCMController@show')->name('modele-qcm');
Route::post('/modele-qcm','QCMController@verif');
