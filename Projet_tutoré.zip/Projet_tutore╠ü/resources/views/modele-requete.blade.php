@extends('layout')

@section('contenu')
<div class="container">
  <div class="jumbotron">
    <h2 id="jumbotron-titre">Requêtes complètes -
      <?php
      $info_exos = DB::select('select * from requete_completes where idEx = '.Route::input('idEx').' and idDom='.Route::input('idDom'));
      $domaine = $info_exos[0]->domaine;
      // $domaine = DB::select('select domaine from requete_completes where idEx = '.Route::input('idEx').' and idDom='.Route::input('idDom'))[0]->domaine;
      echo $domaine;
      ?>
      - Exercice <?php echo Route::input('idEx'); ?></h2>
      <p id="jumbotron-p" class="question">
        <div>
          <?php
          echo $info_exos[0]->question;
          ?>
        </div>
      </p>
    </div>


    <div id="rep">
      <!-- Requête de l'élève -->
      <form id ="form" class="form-group">
        {{ csrf_field() }}
        <div class="form-group">
          <label for="requete">Tapez votre requête : </label>
          <textarea class="form-control" name="rep" id="requete" rows="5"></textarea>
        </div>
        <div>
          <?php if($info_exos[0]->typeSELECT == 1){ ?>
            <button id="btn-executer" type="button" class="btn btn-primary">Exécuter la requête</button>
          <?php } ?>
          <button id="btn-valider" type="submit" class="btn btn-primary">Valider</button>
        </div>
      </form>


      <?php
      $idExSuiv = Route::input('idEx') + 1;
      $count = DB::table('requete_completes')->where([
        ['idDom','=',Route::input('idDom')],
        ['idEx','=',$idExSuiv]
        ])->count();

        if($count == 0){
          ?>

          <div style="display:none"  id ="success" class="alert alert-success">
            <strong>Bien joué !</strong> Accéder au <a href="menu-exercice" class="alert-link">menu des exercices</a>.
          </div>

          <?php
        }
        else{
          ?>

          <div style="display:none" id ="success" class="alert alert-success">
            <strong>Bien joué !</strong> Accéder à <a href=
            <?php $idEx = Route::input('idEx')+1; echo '"modele-requete.'.Route::input('idDom').'.'.$idEx.'"'; ?>
            class="alert-link">l'exercice suivant </a>.
          </div>

          <?php
        }
        ?>

        <div style="display:none" id="echec" class="alert alert-danger">
          <strong>Faux !</strong>
        </div>

        <div style="display:none" id="info" class="alert alert-info">
          <strong>Erreur dans l'exécution de la requête.</strong>
        </div>


        <!-- Résultat de la requête -->

        <label id="label-reponse"></label>
        <div id="reponse" rows="5">
        </div>

      </div>




      <!-- Trigger the modal with a link : AIDE -->
      <a id="aide" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-question-sign"></span>aide</a>

      <!-- Modal -->
      <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Aide</h4>
            </div>
            <div class="modal-body">
              <p>
                <?php
                echo DB::select('select aide from requete_completes where idDom = '.Route::input('idDom'))[0]->aide;
                ?>
              </p>
            </div>
          </div>

        </div>
      </div>
      <!-- end modal -->

    </div>

    <script>
    idEx= <?php echo Route::input('idEx'); ?>;
    idDom= <?php echo Route::input('idDom'); ?>;
    domaine= "<?php echo $info_exos[0]->domaine; ?>";
    typeSELECT= <?php echo $info_exos[0]->typeSELECT; ?>;
    </script>
    <script src="js/requete_completes.js"></script>

    @endsection
