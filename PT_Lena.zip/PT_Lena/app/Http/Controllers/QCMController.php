<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class QCMController extends Controller
{
  public function modeleQcm(){
        return view('modele-qcm');
  }

 public function show(int $id){
   return view('modele-qcm');
 }

 // public function optionChoix(){
 //   //2nd parameter means, if radio is not selected then use default value
 //   $radio = $id->get('optradio', 0);
 //   echo $radio;
 // }

}
