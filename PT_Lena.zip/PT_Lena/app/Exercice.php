<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Exercice extends Model
{
  public $timestamps = false;
}
