<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::view('/','welcome');

Route::view('/accueil','accueil');

Route::get('/inscription', 'InscriptionController@afficherFormulaire');
Route::post('/inscription', 'InscriptionController@traiterFormulaire');
Route::post('/modele-qcm{id}', 'QcmController@optionChoix');

Route::get('/connexion', 'ConnexionController@afficherFormulaire');
Route::post('/connexion', 'ConnexionController@traiterFormulaire');

Route::view('/modele-exercice','modele-exercice');
Route::view('/modele-cours','modele-cours');
Route::view('/modele-notes','modele-notes');
Route::view('/modele-qcm','modele-qcm');

Route::view('/menu-exercice','menu-exercice');

Route::view('/exercice-tout','exercice-tout');
Route::view('/cours-tout','cours-tout');
Route::view('/exercice-requete','exercice-requete');

Route::get('/testQCM', 'QCMController@afficher');

Route::post('/testQCM', 'QCMController@functionTest');

Route::get('/modele-exercice{id}','MenuExerciceController@show')->name('modele-exercice');
Route::get('/modele-cours{titre}','MenuCoursController@show')->name('modele-cours');
Route::get('/modele-qcm{id}','QCMController@show')->name('modele-qcm');
