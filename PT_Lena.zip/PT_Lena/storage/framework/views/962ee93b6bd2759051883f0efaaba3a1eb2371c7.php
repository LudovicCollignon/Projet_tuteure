<?php $__env->startSection('contenu'); ?>
<div class="container">
  <ul class="list-group">
    <?php
      $cours = App\Cours::all();
      foreach($cours as  $key => $c){
        echo "<li class=\"list-group-item\"><a class=\"dropdown-item\" href=\""
            .route('modele-cours', [$c->titre])
            ."\">"
            .$c->titre
            ."</a></li>";
      }
     ?>
  </ul>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>