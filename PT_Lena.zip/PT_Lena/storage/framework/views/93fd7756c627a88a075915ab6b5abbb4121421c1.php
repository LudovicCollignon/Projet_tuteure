<?php $__env->startSection('mon-CSS'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/exercice-tout.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenu'); ?>
<div class="container">
  <div class="row">

    <div class="exos">
      <div class="container">
        <a href="#">
          <div class="text-center" data-toggle="collapse" href="#QCM-exos" role="button" aria-expanded="false" aria-controls="QCM-exos">
            <h2>QCM</h2>
            <p>Entraînez-vous avec des questions à choix multiples (QCM) sur les sujets abordés dans les cours</p>
          </div>
        </a>
      </div>
    </div>
    <div class="collapse multi-collapse" id="QCM-exos">
      <div class="card card-body">
        <div class="row">
          <div class="col-sm-4">
            <ul>
              <?php
                $exos = App\Qcm::all();
                foreach($exos as  $key => $e){
                  echo "<div class=\"col-1-1\"><a class=\"dropdown-item\" href=\""
                      .route('modele-qcm', [$e->id])
                      ."\"> Exercice "
                      .$e->id
                      ."</a></div>";
                }
               ?>
            </ul>
          </div>
      </div>
    </div>
  </div>

    <div class="exos">
      <div class="container">
        <a href="#">
          <div class="text-center" data-toggle="collapse" href="#TAT-exos" role="button" aria-expanded="false" aria-controls="TAT-exos">
            <h2>Textes à trous</h2>
            <p>Description</p>
          </div>
        </a>
      </div>
    </div>
    <div class="collapse multi-collapse" id="TAT-exos">
      <div class="card card-body">
        <div class="row">
          <div class="col-sm-4">
            <ul>
              <li><a href="#">Exercice 1</a></li>
              <li><a href="#">Exercice 2</a></li>
              <li><a href="#">Exercice 3</a></li>
              <li><a href="#">Exercice 4</a></li>
              <li><a href="#">Exercice 5</a></li>
            </ul>
          </div>
          <div class="col-sm-4">
            <ul>
              <li><a href="#">Exercice 1</a></li>
              <li><a href="#">Exercice 2</a></li>
              <li><a href="#">Exercice 3</a></li>
              <li><a href="#">Exercice 4</a></li>
              <li><a href="#">Exercice 5</a></li>
            </ul>
          </div>
          <div class="col-sm-4">
            <ul>
              <li><a href="#">Exercice 1</a></li>
              <li><a href="#">Exercice 2</a></li>
              <li><a href="#">Exercice 3</a></li>
              <li><a href="#">Exercice 4</a></li>
              <li><a href="#">Exercice 5</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <div class="exos">
      <div class="container">
        <a href="#">
          <div class="text-center" data-toggle="collapse" href="#RC-exos" role="button" aria-expanded="false" aria-controls="RC-exos">
            <h2>Requêtes complètes</h2>
            <p>Description</p>
          </a>
        </div>
      </div>
    </div>
    <div class="collapse multi-collapse" id="RC-exos">
      <div class="card card-body">
        <div class="row">
          <div class="col-sm-4">
            <ul>
              <li><a href="#">Exercice 1</a></li>
              <li><a href="#">Exercice 2</a></li>
              <li><a href="#">Exercice 3</a></li>
              <li><a href="#">Exercice 4</a></li>
              <li><a href="#">Exercice 5</a></li>
            </ul>
          </div>
          <div class="col-sm-4">
            <ul>
              <li><a href="#">Exercice 1</a></li>
              <li><a href="#">Exercice 2</a></li>
              <li><a href="#">Exercice 3</a></li>
              <li><a href="#">Exercice 4</a></li>
              <li><a href="#">Exercice 5</a></li>
            </ul>
          </div>
          <div class="col-sm-4">
            <ul>
              <li><a href="#">Exercice 1</a></li>
              <li><a href="#">Exercice 2</a></li>
              <li><a href="#">Exercice 3</a></li>
              <li><a href="#">Exercice 4</a></li>
              <li><a href="#">Exercice 5</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>