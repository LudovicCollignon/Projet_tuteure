<?php $__env->startSection('contenu'); ?>
  <div class="container">

    <!-- titre du cours -->
    <div class="page-header">
      <h1><b><?php echo Route::input('titre'); ?></b></h1>
    </div>

    <!-- contenu du cours -->
    <!-- <h1>INSERT</h1>
    <p id="def-insert">L’insertion de données dans une table s’effectue à l’aide de la commande <code>INSERT INTO</code>.<br>
      Cette commande permet au choix d’inclure une seule ligne à la base existante ou plusieurs lignes d’un coup.</p>
    <p>Le nombre de colonnes doit être identique au nombre de valeurs. Si une colonne n'est pas spécifiée, sa valeur par défaut lui sera affectée.
       Les valeurs insérées doivent respecter toutes les contraintes tel que les <u><a href="#def-cle-etrangere">clés étrangères</a></u>, <u><a href="#def-cle-primaire">clés primaires</a></u>, et les <u>colonnes</u> <b>NOT NULL</b>.
        <br>Si la commande contient une erreur de syntaxe, ou si une contrainte n'est pas respectée, les valeurs ne sont pas insérées et une erreur est rapportée.</p>

        <p id="def-cle-etrangere"><b>La clé étrangère</b> représente un champ (ou des champs) qui pointe vers la clé primaire d’une autre table. L’objectif de la clé étrangère est d’assurer l’intégrité référentielle des données. En d’autres mots, seules les valeurs devant apparaître dans la base de données sont permises.</p>
        <p id="def-cle-primaire"><b>La clé primaire</b> concourt à identifier uniquement chaque ligne d’une table. Elle peut représenter une partie d’un enregistrement concret, ou être un champ artificiel (un champ qui n’a rien à voir avec l’enregistrement réel). La clé primaire peut représenter un ou plusieurs champs d’une table. Lorsque la clé primaire représente plusieurs champs, elle est appelée « clé composite ».
          Il est possible de spécifier les clés primaires au moment de la création de la table (à l’aide de <code>CREATE TABLE</code>) ou de la modification de la structure de la table existante (par le biais de <code>ALTER TABLE</code>).</p>

      <br>
      <p>Syntaxe :</p>
      <pre>
        INSERT INTO table (column1 [, column2, column3 ... ]) VALUES (value1 [, value2, value3 ... ])</pre>
      <br>
      <p>Exemple :</p>
      <p>On a la table Clients suivante : </p>
      <table class="table">
           <thead>
             <tr>
               <th scope="col">Id</th>
               <th scope="col">Prénom</th>
               <th scope="col">Nom</th>
               <th scope="col">Age</th>
             </tr>
           </thead>
           <tbody>
             <tr>
               <td>1</td>
               <td>Théo</td>
               <td>Marin</td>
               <td>17</td>
             </tr>
             <tr>
               <td>2</td>
               <td>Lily</td>
               <td>James</td>
               <td>24</td>
             </tr>
             <tr>
               <td>3</td>
               <td>John</td>
               <td>Collin</td>
               <td>34</td>
             </tr>
             <tr>
               <td>4</td>
               <td>Amanda</td>
               <td>Petit</td>
               <td>27</td>
             </tr>
           </tbody>
         </table>
         <p>On souhaite insérer un nouveau client : </p>
      <pre>
        INSERT INTO Clients VALUES (5, Joseph, Tyler, 30);</pre>
        <table class="table">
             <thead>
               <tr>
                 <th scope="col">Id</th>
                 <th scope="col">Prénom</th>
                 <th scope="col">Nom</th>
                 <th scope="col">Age</th>
               </tr>
             </thead>
             <tbody>
               <tr>
                 <td>1</td>
                 <td>Théo</td>
                 <td>Marin</td>
                 <td>17</td>
               </tr>
               <tr>
                 <td>2</td>
                 <td>Lily</td>
                 <td>James</td>
                 <td>24</td>
               </tr>
               <tr>
                 <td>3</td>
                 <td>John</td>
                 <td>Collin</td>
                 <td>34</td>
               </tr>
               <tr>
                 <td>4</td>
                 <td>Amanda</td>
                 <td>Petit</td>
                 <td>27</td>
               </tr>
               <tr>
                 <td>5</td>
                 <td>Joseph</td>
                 <td>Tyler</td>
                 <td>30</td>
               </tr>
             </tbody>
           </table> -->

    <div id="cours-contenu" class="cours">
      <?php
        // $cours = App\Cours::where('id', 1)->get();
        $cours = App\Cours::where('titre', Route::input('titre'))->first();
        echo $cours->contenu;
      ?>

    </div>

    <div>
      <label>Essayez ce que vous venez d'apprendre avec des <a href="exercice-tout">exercices</a>.</label>
    </div>

  
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>