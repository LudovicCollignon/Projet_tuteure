<?php $__env->startSection('contenu'); ?>
<body>
  <div id="background-img"></div>

  <div class="container">
    <h1>Présentation</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    <p>Complétez la requête suivante pour pouvoir obtenir tous les champs de la table <code>country</code> ou la colonne \"Name\" est triée par ordre alphabétique :<br>

</p>
<pre>
  SELECT * FROM country
  __________________;
</pre>
  </div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>