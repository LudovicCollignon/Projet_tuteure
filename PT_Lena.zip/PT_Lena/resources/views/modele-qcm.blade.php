@extends('layout')

@section('contenu')
  <div class="container">
    <div class="jumbotron">
      <h1>QCM - Exercice
        <?php echo Route::input('id'); ?>
      </h1>
      <p id="jumbotron" class="question">
        <?php
          $question = App\Qcm::find(Route::input('id'));
          echo $question->question;
        ?>
      </p>
    </div>

    <form id="options" method="post">
      {{ csrf_field() }}

    <label class="radio-inline">
      <!-- Si l'option est vide, l'input ne sera pas affiché -->
      <?php
        $opt = App\Qcm::find(Route::input('id'));
        if($opt->a == ""){
          echo "<input type=\"radio\" name=\"optradio\" style=\"display:none;\">";
        }else{
        echo "<input type=\"radio\" name=\"optradio\">";
      }
      ?>


      <?php
        $opt = App\Qcm::find(Route::input('id'));
        echo $opt->a;
      ?>
    </label>


    <label class="radio-inline">
      <?php
        $opt = App\Qcm::find(Route::input('id'));
        if($opt->b == ""){
          echo "<input type=\"radio\" name=\"optradio\" style=\"display:none;\">";
        }else{
        echo "<input type=\"radio\" name=\"optradio\">";
      }
      ?>

      <?php
        $opt = App\Qcm::find(Route::input('id'));
        echo $opt->b;
      ?>
    </label>

        <label class="radio-inline">
          <?php
            $opt = App\Qcm::find(Route::input('id'));
            if($opt->c == ""){
              echo "<input type=\"radio\" name=\"optradio\" style=\"display:none;\">";
            }else{
            echo "<input type=\"radio\" name=\"optradio\">";
          }
          ?>

          <?php
            $opt = App\Qcm::find(Route::input('id'));
            echo $opt->c;
          ?>
        </label>




        <label class="radio-inline">
          <?php
            $opt = App\Qcm::find(Route::input('id'));
            if($opt->d == ""){
              echo "<input type=\"radio\" name=\"optradio\" style=\"display:none;\">";
            }else{
            echo "<input type=\"radio\" name=\"optradio\">";
          }
          ?>

          <?php
            $opt = App\Qcm::find(Route::input('id'));
            echo $opt->d;
          ?>
        </label>



        <button id="btn-valider" type="submit" class="btn btn-primary">Valider</button>
  </form>

    <!-- Trigger the modal with a link -->
    <a id="aide" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-question-sign"></span>aide</a>

    <!-- Modal -->
    <div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Aide</h4>
          </div>

          <div class="modal-body">
            <p>
              <!-- Mettre l'aide dans la base de données -->
            <?php
              $cour = App\Qcm::find(Route::input('id'));
              echo $cour->aide;
            ?></p>
          </div>
        </div>
      </div>
    </div>
    <!-- end modal -->

  </div>

@endsection
