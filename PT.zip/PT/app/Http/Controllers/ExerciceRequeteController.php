<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Requete_complete;
use DB;
use PDO;

class ExerciceRequeteController extends Controller
{
  // validation de l'exercice, return un booléen
  public function validation(int $idDom, int $idEx){
    header('content-Type:application/json');

    $type_exo = DB::select('select typeSELECT from requete_completes where idEx='.$idEx.' and idDom='.$idDom)[0]->typeSELECT;

    if($type_exo ==  1) {
      $res = ExerciceRequeteController::avecResultat($idDom, $idEx);
    } else {
      $res = ExerciceRequeteController::sansResultat($idDom, $idEx);
    }

    echo json_encode($res);
  }


  // comparaison des requêtes de type SELECT (avec résultat)
  public function avecResultat(int $idDom, int $idEx){
    try {
      $bdd = new PDO('mysql:host=dwarves.iut-fbleau.fr;dbname=khalfi', 'khalfi', 'fianso');
    } catch(PDOException $e) {
      die('could not connect');
    }

    $statement1 = $bdd->prepare($_POST['rep']);
    $statement1->execute();
    $request1 = $statement1->fetchAll();

    $statement2 = $bdd->prepare(DB::select('select reponse from requete_completes where idEx='.$idEx.' and idDom='.$idDom)[0]->reponse);
    $statement2->execute();
    $request2 = $statement2->fetchAll();

    if($request1 == $request2){
      return true;
    } else {
      return false;
    }
  }

  // comparaison des requêtes de type UPDATE, INSERT INTO (sans résultat)
  public function sansResultat(int $idDom, int $idEx){

    $reponse = DB::select('select reponse from requete_completes where idEx='.$idEx.' and idDom='.$idDom)[0]->reponse;

    // transformation de la requête utilisateur (supression des espace, remplacement de " en ', ajout du ; )
    $str = strtolower($_POST['rep']);
    $str = str_replace(' ','',$str);
    $str = str_replace('\n','',$str);
    $str = str_replace('\r','',$str);
    $str = str_replace('"','\'',$str);

    if(strpos($str, ";") === false){
      $str .= ";";
    }
    return $reponse === $str;
  }


  // exécution de la requête de l'utilisateur = return le résultat dans un tableau
  public function exec(int $idDom, int $idEx) {
    header('content-Type:application/json');

    try {
      $bdd = new PDO('mysql:host=dwarves.iut-fbleau.fr;dbname=khalfi', 'khalfi', 'fianso');
    } catch(PDOException $e) {
      die('could not connect');
    }

    $requete_utilisateur = strtolower($_POST['rep']);
    $statement1 = $bdd->prepare($requete_utilisateur);
    $statement1->execute();
    $request1 = $statement1->fetchAll();

    $tab = [];
    foreach ($request1 as $key => $value) {
      $c = true;
      $tableau = [];
      foreach ($value as $cle => $valeur) {
        if($c == true){
          array_push($tableau, [$cle => $valeur]);
          $c = false;
        }else{
          $c = true;
        }
      }
      array_push($tab, $tableau);
    }

    echo json_encode($tab);
  }

  public function show(int $iDom, int $idEx){
    return view('modele-requete');
  }
}
