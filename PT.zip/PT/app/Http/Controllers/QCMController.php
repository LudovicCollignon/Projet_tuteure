<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class QCMController extends Controller
{
  public function modeleQcm(){
        return view('modele-qcm');
  }

 public function show(int $idDom, int $idEx){
   return view('modele-qcm');
 }

 public function verif(Request $request){
   header('content-Type:application/json');

   //$requete = App\Text_a_trou::select('rep1','rep2','rep3','rep4')->whereRaw('numChap = '.$request->idChap.' and numQuest = '.$request->idQuest)->get();
   $requete=DB::table('qcms')->where([
     ['idDom','=',$request->idDom],
     ['idEx','=',$request->idEx],
   ])->first();

   $reponse = ['verdict'=>"false"];

   if($requete->reponse == $request->reponse){
        $reponse = ['verdict'=>"true"];
   }

   return response()->json($reponse);

 }


 // public function optionChoix(){
 //   //2nd parameter means, if radio is not selected then use default value
 //   $radio = $id->get('optradio', 0);
 //   echo $radio;
 // }

}
