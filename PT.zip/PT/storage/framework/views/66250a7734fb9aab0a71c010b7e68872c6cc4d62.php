<form method="post" action="vue">
  <?php echo e(csrf_field()); ?>

  <input type="text" name="oui" value="">
  <input type="submit" name="submit" value="Valider">
</form>
