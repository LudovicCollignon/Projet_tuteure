<?php $__env->startSection('contenu'); ?>
<div class="container">

  <!-- titre du cours -->
  <div class="page-header">
    <h1><b><?php echo Route::input('titre'); ?></b></h1>
  </div>

  <!-- contenu du cours -->
  <div id="cours-contenu" class="cours">
    <?php
    // $cours = App\Cours::where('id', 1)->get();
    $cours = App\Cours::where('titre', Route::input('titre'))->first();
    echo $cours->contenu;
    ?>
  </div>

  <div>
    <label>Essayez ce que vous venez d'apprendre avec des <a href="menu-exercice">exercices</a>.</label>
    <br><br><br>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>