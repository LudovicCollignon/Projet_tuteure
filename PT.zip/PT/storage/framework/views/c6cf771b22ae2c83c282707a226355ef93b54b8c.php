<!-- Modif -->

<?php $__env->startSection('contenu'); ?>
<div class="container" id="inscription--page">
  <h1>Inscription</h1>
  <div class="jumbotron">
    <form action="/inscription" method="post">
      <?php echo e(csrf_field()); ?>


      <div class="form-group">
        <label>Nom</label>
        <p><input id="nom" class="form-control" type="text" name="nom" placeholder="Dupont" value="<?php echo e(old('nom')); ?>"></p>
        <?php if($errors->has('nom')): ?>
        <p><?php echo e($errors->first('nom')); ?></p>
        <?php endif; ?>
      </div>

      <div class="form-group">
        <label>Prénom</label>
        <p><input id="prenom" class="form-control" type="text" name="prenom" placeholder="Pierre" value="<?php echo e(old('prenom')); ?>"></p>
        <?php if($errors->has('prenom')): ?>
        <p><?php echo e($errors->first('prenom')); ?></p>
        <?php endif; ?>
      </div>

      <div class="form-group">
        <label>Adresse mail</label>
        <p><input id="email" class="form-control" type="mail" name="email" placeholder="your@mail.com" value="<?php echo e(old('email')); ?>"></p>
        <?php if($errors->has('email')): ?>
        <p><?php echo e($errors->first('email')); ?></p>
        <?php endif; ?>
      </div>

      <div class="form-group">
        <label>Mot de passe</label>
        <p><input id="password" class="form-control" type="password" name="password" placeholder="Mot de passe"></p>
        <?php if($errors->has('password')): ?>
        <p><?php echo e($errors->first('password')); ?></p>
        <?php endif; ?>

        <p><input id="pwd-conf" class="form-control" type="password" name="password_confirmation" placeholder="Confirmez votre mot de passe"></p>
        <?php if($errors->has('password_confirmation')): ?>
        <p><?php echo e($errors->first('password_confirmation')); ?></p>
        <?php endif; ?>
      </div>

      <p><input id="submit" class="btn btn-primary" type="submit" value="M'inscrire"></p>
    </form>
    <p>Déjà inscrit ?<a href="connexion"> Connectez-vous.</a></p>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>