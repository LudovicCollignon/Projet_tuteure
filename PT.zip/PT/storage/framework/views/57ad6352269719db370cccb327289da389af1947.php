<?php $__env->startSection('contenu'); ?>
<body>
  <div id="background-img"></div>

  <div class="container">
    <h3>SQLearning, c'est quoi ?</h3>
    <p>SQLearning est un site destiné aux personnes souhaitant découvrir le langage de bases de données MySQL.</p>

    <h3>Les cours</h3>
    <p>Les principales notions du langage MySQL sont abordées dans les cours que nous vous proposons.</p>

    <h3>Les exercices</h3>
    <p>Différents types d'exercices vous permettront de tester vos connaissances :  </p>
    <ul>
      <li>QCM : Entraînez vous avec un questionnaire à choix multiples sur les sujets abordés dans les cours.</li>
      <li>Textes à trous : Exercez vous en remplissant ces textes à trous avec les mots clés SQL que vous avez appris.</li>
      <li>Requêtes complètes : Testez vos connaissances en vous entraînant à rédiger des requêtes SQL complètes.</li>
    </ul>

  </div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>