<?php $__env->startSection('contenu'); ?>

<script type="text/javascript" src="<?php echo e(asset('js/qcm.js')); ?>"></script>
<div class="container">

  <?php
  $idEx = Route::input('idEx');
  $idDom = Route::input('idDom');
  $requete = App\Qcm::whereRaw('idDom = '.$idDom.' and idEx = '.$idEx)->first();

  echo '<div class="jumbotron"><h2>Texte à trous - '.$requete->domaine.' - Exercice '.$idEx.'</h2>';
  ?>

    <p class="question">
      <?php echo e($requete->question); ?>

    </p>
  </div>

  <form id="options" method="post">
    <?php echo e(csrf_field()); ?>


    <label class="radio-inline">
      <!-- Si l'option est vide, l'input ne sera pas affiché -->
      <?php
      if($requete->a == ""){
        echo "<input type=\"radio\" name=\"optradio\" style=\"display:none;\" id=\"a\" value=\"".$requete->a."\">";
      }else{
        echo "<input type=\"radio\" name=\"optradio\" id=\"a\" value=\"".$requete->a."\">";
      }
      ?>


      <?php
      echo $requete->a;
      ?>
    </label>


    <label class="radio-inline">
      <?php
      if($requete->b == ""){
        echo "<input type=\"radio\" name=\"optradio\" style=\"display:none;\" id=\"b\" value=\"".$requete->b."\">";
      }else{
        echo "<input type=\"radio\" name=\"optradio\" id=\"b\" value=\"".$requete->b."\">";
      }
      ?>

      <?php
      echo $requete->b;
      ?>
    </label>

    <label class="radio-inline">
      <?php
      if($requete->c == ""){
        echo "<input type=\"radio\" name=\"optradio\" style=\"display:none;\" id=\"c\" value=\"".$requete->c."\">";
      }else{
        echo "<input type=\"radio\" name=\"optradio\" id=\"c\" value=\"".$requete->c."\">";
      }
      ?>

      <?php
      echo $requete->c;
      ?>
    </label>




    <label class="radio-inline">
      <?php
      if($requete->d == ""){
        echo "<input type=\"radio\" name=\"optradio\" style=\"display:none;\" id=\"d\" value=\"".$requete->d."\">";
      }else{
        echo "<input type=\"radio\" name=\"optradio\" id=\"d\" value=\"".$requete->d."\">";
      }
      ?>

      <?php
      echo $requete->d;
      ?>
    </label>



    <button id="btn-valider" type="submit" class="btn btn-primary">Valider</button>
  </form>

  <!-- Trigger the modal with a link -->
  <a id="aide" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-question-sign"></span>aide</a>

  <!-- Modal -->
  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Aide</h4>
        </div>

        <div class="modal-body">
          <p>
            <!-- Mettre l'aide dans la base de données -->
            <?php
            echo $requete->aide;
            ?></p>
          </div>
        </div>
      </div>
    </div>
    <!-- end modal -->
    <?php
    $idExSuiv = $idEx + 1;
    $count = DB::table('qcms')->where([
      ['idDom','=',$idDom],
      ['idEx','=',$idExSuiv],
      ])->count();

      if($count == 0){
        echo'
        <div style=display:none id ="success" class="alert alert-success">
        <strong>Bien joué !</strong> Accéder au <a href="menu-exercice" class="alert-link">menu des exercices</a>.
        </div>
        ';
      }
      else{
        echo'
        <div style=display:none id ="success" class="alert alert-success">
        <strong>Bien joué !</strong> Accéder à <a href="'.route('modele-qcm', [$idDom, $idExSuiv]).'" class="alert-link">l\'exercice suivant </a>.
        </div>
        ';
      }

      echo'
      <div style=display:none id="echec" class="alert alert-danger">
      <strong>Faux !</strong> Tu peux réessayer, pense à te servir de l\'aide.
      </div>
      ';

      echo'
      <div style=display:none id="info" class="alert alert-info">
      Erreur dans la validation de la réponse.
      </div>
      ';


    echo "<script>
    var idEx = '".$idEx."';
    var idDom = '".$idDom."';
    </script>";

    ?>


  </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>