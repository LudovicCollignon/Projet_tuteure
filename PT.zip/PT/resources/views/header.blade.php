<header>
  <nav id="navbar-menu" class="navbar navbar-inverse">
    <div class="container-fluid">

      <div class="navbar-header">
        <a id="navbar-menu-titre" class="navbar-brand" href="accueil">SQLearning</a>
      </div>

      <button id="navbar-menu-button-collapse" type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <div class="collapse navbar-collapse" id="myNavbar">
        <ul id="navbar-menu-onglet" class="nav navbar-nav">
          <li id="navbar-menu-onglet-cours">
            <a class="dropdown-toggle" href="menu-cours">COURS</a>
          </li>
          <li id="navbar-menu-onglet-exercices">
            <a class="dropdown-toggle" href="menu-exercice">EXERCICES</a>
          </li>
        </ul>

        <ul id="navbar-menu-connect" class="nav navbar-nav navbar-right">
          <li id="navbar-menu-inscription"><a href="inscription"><span id="glyphicon-inscription" class="glyphicon glyphicon-user"></span> Inscription</a></li>
          <li id="navbar-menu-connexion"><a href="connexion"><span id="glyphicon-connexion" class="glyphicon glyphicon-log-in"></span> Connexion</a></li>
        </ul>
      </div>
    </div>
  </nav>
</header>
