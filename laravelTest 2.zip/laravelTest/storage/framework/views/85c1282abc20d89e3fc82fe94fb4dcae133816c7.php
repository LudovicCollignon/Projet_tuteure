<?php $__env->startSection('contenu'); ?>
<form action="/inscription" method="post">
  <?php echo e(csrf_field()); ?>

  <input type"text" name="nom" placeholder="Nom">
  <input type"text" name="prénom" placeholder="Prénom">
  <input type"email" name="email" placeholder="Email">
  <input type"password" name="password" placeholder="Mot de passe">
  <input type"password" name="password_confirmation" placeholder="Confirmer Mot de passe">
  <input type"submit" value="M'inscrire">
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>