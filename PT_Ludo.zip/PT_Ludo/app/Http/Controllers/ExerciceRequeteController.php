<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Requete_complete;
use DB;
use PDO;

class ExerciceRequeteController extends Controller
{
  public function test(){
    header('content-Type:application/json');

    try {
      $bdd = new PDO('mysql:host=dwarves.iut-fbleau.fr;dbname=khalfi', 'khalfi', 'fianso');
    } catch(PDOException $e) {
      die('could not connect');
    }



    $statement1 = $bdd->prepare($_POST['rep']);
    $statement1->execute();
    $request1 = $statement1->fetchAll();

    $statement2 = $bdd->prepare(DB::select('select reponse from requete_completes where id = '.$_POST['id'])[0]->reponse);
    $statement2->execute();
    $request2 = $statement2->fetchAll();

    echo json_encode(ExerciceRequeteController::compare($request1, $request2));

    // $test = gettype(DB::select('select reponse from requete_completes where id = 1')[0]->reponse);
    //
    // echo json_encode($test);
  }

  public function compare(array $request1, array $request2) {
    // code de comparaison des deux fonctions.
    if($request1 == $request2){
      return true;
    } else {
      return false;
    }
  }

  public function exec() {
    header('content-Type:application/json');

    try {
      $bdd = new PDO('mysql:host=dwarves.iut-fbleau.fr;dbname=khalfi', 'khalfi', 'fianso');
    } catch(PDOException $e) {
      die('could not connect');
    }
    // $requete_utilisateur = strtoupper($_POST['rep']);
    $statement1 = $bdd->prepare($_POST['rep']);
    // $statement1 = $bdd->prepare("select * from country");
    $statement1->execute();
    $request1 = $statement1->fetchAll();

    $tab = [];
    foreach ($request1 as $key => $value) {
      $c = true;
      $tableau = [];
      foreach ($value as $cle => $valeur) {
        if($c == true){
          array_push($tableau, [$cle => $valeur]);
          $c = false;
        }else{
          $c = true;
        }
      }
      array_push($tab, $tableau);
    }

    echo json_encode($tab);
  }

  public function show(int $id){
    return view('exercice-requete');
  }
}
