<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Requete_complete;
use DB;
use PDO;

class Requete_complete_test extends Controller
{




  public function test(){
    header('content-Type:application/json');



    try {
      $bdd = new PDO('mysql:host=dwarves.iut-fbleau.fr;dbname=khalfi', 'khalfi', 'fianso');
    } catch(PDOException $e) {
      die('could not connect');
    }

    // $statement1 = $bdd->prepare($_POST['rep']);
    //   $statement1->execute();
    //   $request1 = $statement1->fetchAll();
    //
    //   $statement2 = $bdd->prepare();
    //   $statement2->execute();
    //   $request2 = $statement2->fetchAll();



      // if(sizeof($result1)==0 && sizeof($request2)==0) {
      //   echo json_encode("beau gosse");
      // }else{
      //   echo json_encode("dommage");
      // }
      // dump(compare($result1));
      // echo json_encode(Requete_complete_test::compare($request1, $request2));

      // $res = DB::select('select question from requete_completes where id = 1');

      // $a = json_decode($res[0]);
      echo json_encode("ui");



      // SELECT * FROM table_test as TA
      // LEFT JOIN (SELECT * FROM table_test) as TB ON TA.col1 = TB.col1
      // WHERE TB.col1 IS NULL
      //
      // SELECT * FROM table_test as TB
      // LEFT JOIN (SELECT * FROM table_test) as TA ON TB.col1 = TA.col1
      // WHERE TA.col1 IS NULL


      // WITH
      // TA AS (select * from posts),
      // TB AS (select * from posts where id=2)
      // SELECT * FROM TA
      // LEFT JOIN TB ON TA.id = TB.id
      // WHERE TB.id IS NULL;
      //
      // WITH
      // TA AS (select * from posts),
      // TB AS (select * from posts where id=2)
      // SELECT * FROM TB
      // LEFT JOIN TA ON TB.id = TA.id
      // WHERE TA.id IS NULL;

    }

    private function compare(array $request1, array $request2) {
      // code de comparaison des deux fonctions.

      $result = $request1[0];

      if($request1 == $request2){
        return "OK";
      } else {
        return "not OK";
      }
    }
  }
