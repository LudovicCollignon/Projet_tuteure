<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use PDO;

class Control extends Controller
{

  public function autre_fonction()
  {
    $str = "ok";
    return $str;
  }

  public function fonction()
  {


    $requete_utilisateur = strtoupper("requbkfesdlf sdlf");






    dump(gettype($requete_utilisateur));
  }



}
