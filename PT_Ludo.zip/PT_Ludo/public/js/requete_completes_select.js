empecher("delete");
empecher("update");
empecher("alter table");
empecher("insert");
