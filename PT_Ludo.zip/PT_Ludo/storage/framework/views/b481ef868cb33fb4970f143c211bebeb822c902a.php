<div id="inscription--modal" class="modal fade">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="modal-title">Inscription</h3>
      </div>
      <div class="modal-body">
        <form action="/inscription" method="post">
          <div class="form-group">
            <label>Nom</label>
            <?php echo e(csrf_field()); ?>

            <p><input class="form-control" type="text" name="nom" placeholder="Nom" value="<?php echo e(old('nom')); ?>"></p>
            <?php if($errors->has('nom')): ?>
              <p><?php echo e($errors->first('nom')); ?></p>
            <?php endif; ?>
          </div>

          <div class="form-group">
            <label>Prénom</label>
            <p><input class="form-control" type="text" name="prenom" placeholder="Prénom" value="<?php echo e(old('prenom')); ?>"></p>
            <?php if($errors->has('prenom')): ?>
              <p><?php echo e($errors->first('prenom')); ?></p>
            <?php endif; ?>
          </div>

          <div class="form-group">
            <label>Adresse mail</label>
            <p><input class="form-control" type="mail" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>"></p>
            <?php if($errors->has('email')): ?>
              <p><?php echo e($errors->first('email')); ?></p>
            <?php endif; ?>
          </div>

          <div class="form-group">
            <label>Mot de passe</label>
            <p><input class="form-control" type="password" name="password" placeholder="Mot de passe"></p>
            <?php if($errors->has('password')): ?>
              <p><?php echo e($errors->first('password')); ?></p>
            <?php endif; ?>
          </div>

          <p><input class="form-control" type="password" name="password_confirmation" placeholder="Confirmer Mot de passe"></p>
          <?php if($errors->has('password_confirmation')): ?>
            <p><?php echo e($errors->first('password_confirmation')); ?></p>
          <?php endif; ?>
          <p><input class="btn btn-primary" type="submit" value="M'inscrire"></p>
        </form>
      </div>
    </div>
  </div>
</div>
