<?php



$utilisateur = App\Utilisateur::create([
  'nom' => request('nom'),
  'prenom' => request('prenom'),
  'email' => request('email'),
  'mdp' => bcrypt(request('password'))
]);

?>
