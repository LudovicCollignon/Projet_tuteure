<?php $__env->startSection('contenu'); ?>
<div class="container" id="connexion--page">
  <h1>Connexion</h1>
  <div class="modal-body">
    <form action="/connexion" method="post">
      <?php echo e(csrf_field()); ?>


      <div class="form-group">
        <label>Email</label>
        <p><input class="form-control" type="mail" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>"></p>
        <?php if($errors->has('email')): ?>
        <p><?php echo e($errors->first('email')); ?></p>
        <?php endif; ?>
      </div>

      <div class="form-group">
        <label>Mot de passe</label>
        <p><input class="form-control" type="password" name="password" placeholder="Mot de passe"></p>
        <?php if($errors->has('password')): ?>
        <p><?php echo e($errors->first('password')); ?></p>
        <?php endif; ?>
      </div>

      <p><input class="btn btn-primary" id="seConnecter" type="submit" value="Se connecter"></p>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>