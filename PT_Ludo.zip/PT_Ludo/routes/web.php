<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::view('/','welcome');

Route::view('/accueil','accueil');

Route::get('/inscription', 'InscriptionController@afficherFormulaire');
Route::post('/inscription', 'InscriptionController@traiterFormulaire');

Route::get('/connexion', 'ConnexionController@afficherFormulaire');
Route::post('/connexion', 'ConnexionController@traiterFormulaire');

Route::view('/modele-exercice','modele-exercice');
Route::view('/modele-cours','modele-cours');
Route::view('/modele-notes','modele-notes');
Route::view('/menu-exercice','menu-exercice');
Route::view('/exercice-tout','exercice-tout');

Route::get('/testQCM', 'QCMController@afficher');

Route::post('/testQCM', 'QCMController@functionTest');

Route::get('/modele-exercice{id}','MenuExerciceController@show')->name('modele-exercice');
Route::get('/modele-cours{titre}','MenuCoursController@show')->name('modele-cours');

Route::get('/exercice-requete{id}','ExerciceRequeteController@show')->name('exercice-requete');
Route::post('/exercice-requete{id}','ExerciceRequeteController@test')->name('exercice-requete');
Route::post('/exec-exercice-requete{id}','ExerciceRequeteController@exec')->name('-execexercice-requete');



//Exercices
Route::view('/requete_complete_test','Requete_complete_test');
Route::post('/requete_complete_test','Requete_complete_test@test');

Route::get('/modele-qcm{id}','QCMController@show')->name('modele-qcm');


Route::get('vue', 'Control@fonction');
