<header>
  <nav id="navbar-menu" class="navbar navbar-inverse">
    <div class="container-fluid">

      <div class="navbar-header">
        <a id="navbar-menu-titre" class="navbar-brand" href="accueil">SQLearning</a>
      </div>

      <button id="navbar-menu-button-collapse" type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <div class="collapse navbar-collapse" id="myNavbar">
        <ul id="navbar-menu-onglet" class="nav navbar-nav">
          <li id="navbar-menu-onglet-cours" class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown"  href="cours">COURS<span class="caret"></span></a>
            <div class="dropdown-menu">
              <?php
              $cours = App\Cours::all();
              foreach($cours as  $key => $c){
                echo "<div class=\"col-1-1\"><a class=\"dropdown-item\" href=\""
                .route('modele-cours', [$c->titre])
                ."\">"
                .$c->titre
                ."</a></div>";
              }
              ?>

              <!-- <div id="navbar-menu-onglet-dropdown">
              <div class="row"><h3 class="dropdown-header">SQL</h3></div>
              <div class="col-1-1"><a class="dropdown-item" href="modele-cours">Cours 1</a></div>
              <div class="col-1-2"><a class="dropdown-item" href="modele-cours">Cours 2</a></div>
              <div class="col-1-2"><a class="dropdown-item" href="modele-cours">Cours 3</a></div>
            </div>
            <div id="navbar-menu-onglet-dropdown">
            <div class="row"><h3 class="dropdown-header">PostgreSql</h3></div>
            <div class="col-2-1"><a class="dropdown-item" href="modele-cours">Cours 1</a></div>
            <div class="col-2-2"><a class="dropdown-item" href="modele-cours">Cours 2</a></div>
            <div class="col-2-3"><a class="dropdown-item" href="modele-cours">Cours 3</a></div>
          </div>
          <div id="navbar-menu-onglet-dropdown">
          <div class="row"><h3 class="dropdown-header">PLSQL</h3></div>
          <div class="col-3-1"><a class="dropdown-item" href="modele-cours">Cours 1</a></div>
          <div class="col-3-2"><a class="dropdown-item" href="modele-cours">Cours 2</a></div>
          <div class="col-3-3"><a class="dropdown-item" href="modele-cours">Cours 3</a></div>
        </div> -->
        <h4><a id="voir-tout" class="dropdown-item" href="cours">Voir tout<span class="glyphicon glyphicon-chevron-right"></span></a></h4>
      </div>
    </li>

    <li id="navbar-menu-onglet-exercices" class="dropdown">
      <a class="dropdown-toggle" data-toggle="dropdown" href="exercices">EXERCICES<span class="caret"></span></a>
      <div class="dropdown-menu">
        <div id="navbar-menu-onglet-dropdown">
          <div class="row"><h3 class="dropdown-header">QCM</h3></div>
          <?php
          $exos = App\Qcm::all();
          foreach($exos as  $key => $e){
            echo "<div class=\"col-1-1\"><a class=\"dropdown-item\" href=\""
            .route('modele-qcm', [$e->id])
            ."\"> Exercice "
            .$e->id
            ."</a></div>";
          }
          ?>
        </div>
        <div id="navbar-menu-onglet-dropdown">
          <div class="row"><h3 class="dropdown-header">Textes à trous</h3></div>
          <div class="col-2-1"><a class="dropdown-item" href="modele-exercice">Exercice 1</a></div>
          <div class="col-2-2"><a class="dropdown-item" href="modele-exercice">Exercice 2</a></div>
          <div class="col-2-3"><a class="dropdown-item" href="modele-exercice">Exercice 3</a></div>
        </div>
        <div id="navbar-menu-onglet-dropdown">
          <div class="row"><h3 class="dropdown-header">Requêtes complètes</h3></div>

          <?php
          $cours = App\Requete_complete::all();
          foreach($cours as  $key => $c){
            echo "<div class=\"col-3-1\"><a class=\"dropdown-item\" href=\""
            .route('exercice-requete', [$c->id])
            ."\">"
            ."Exercice ".$c->id
            ."</a></div>";
          }

          ?>

          <div id="accordion">
            <div class="card">
              <div class="card-header" id="headingOne">
                <h5 class="mb-0">
                  <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    SELECT
                  </button>
                </h5>
              </div>

              <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                <div class="card-body">

                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-header" id="headingTwo">
                <h5 class="mb-0">
                  <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    Collapsible Group Item #2
                  </button>
                </h5>
              </div>
              <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                <div class="card-body">
                  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-header" id="headingThree">
                <h5 class="mb-0">
                  <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    Collapsible Group Item #3
                  </button>
                </h5>
              </div>
              <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                <div class="card-body">
                  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
              </div>
            </div>
          </div>






        </div>
        <h4><a id="voir-tout" class="dropdown-item" href="exercice-tout">Voir tout<span class="glyphicon glyphicon-chevron-right"></span></a></h4>
      </div>
    </li>

    <li><a id="navbar-menu-onglet-notes" href="modele-notes">NOTES</a></li>
  </ul>

  <ul id="navbar-menu-connect" class="nav navbar-nav navbar-right">
    <li id="navbar-menu-inscription"><a href="inscription"><span id="glyphicon-inscription" class="glyphicon glyphicon-user"></span> Inscription</a></li>
    <li id="navbar-menu-connexion"><a href="connexion"><span id="glyphicon-connexion" class="glyphicon glyphicon-log-in"></span> Connexion</a></li>
  </ul>
</div>
</div>
</nav>
</header>
