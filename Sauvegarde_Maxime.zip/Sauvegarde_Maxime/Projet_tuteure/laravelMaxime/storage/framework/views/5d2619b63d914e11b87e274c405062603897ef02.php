<?php $__env->startSection('mon-CSS'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/CSS-menu-exercice.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mon-javascript'); ?>
<script type="text/javascript" src="js/javascript-menu-exercice.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenu'); ?>

  <!--rajouter les liens vers les nouvelles pages quand elle seront faites -->
  <div id="qcm" class="container-fluid" onclick="cacherTatAndRc()">
    <div id="lien1">
      QCM
    </div>
    <div id = "listeQCM">
      <ul id = "listeExoQcm">
        <?php
            $test =  DB::table('test')->select("id")->get();
              foreach($test as  $key => $value){
              /*  echo  $value->id;
                echo "<br>";
                */
               //  echo "<li>" ;
               //  echo "<a href='{{ route(";
               //  echo "'menu-exercice'";
               //  echo ", [1]) }}'>EXO 1 </a>";
               // echo "</li";

               echo "<li><a href=\"".route('menu-exercice', [$value->id])."\">EXO ".$value->id." </a></li>";
              }




              ?>
              <!--<li>
                 <a href="<?php echo e(route('menu-exercice', [1])); ?>">EXO 1 </a>
              </li>-->

      </ul>
    </div>
  </div>
  <div id="Tat" class="container-fluid" onclick="fonction2()">
    <div id="lien2">
      Texte à trous
    </div>
  </div>
  <div id="rc"  class="container-fluid" onclick="fonction3()">
    <div id="lien3">
      Requêtes complètes
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>