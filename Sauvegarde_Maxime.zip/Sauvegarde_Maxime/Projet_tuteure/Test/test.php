

<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Test</title>
  <link rel="stylesheet" href="stle.css">
  <script src="script.js"></script>
</head>
<body>
	Entrer la requête : <br>
	<form action="resultatTest.php" method="post">
	Requete	<input type="textarea" name="requete"> <br>
	Valider	<input type="submit" name="Valider"> <br>
	</form>




</body>
</html>


CREATE TABLE tableTest(
	idPersonne int primary key,
	nomPersonne varchar(25),
	age int,
	tailleZizi int
)


INSERT INTO tableTest VALUES(2,"ludo",20,24);
INSERT INTO tableTest VALUES(3,"maxime",18,11);

INSERT INTO tableTest VALUES(4,"hugo",36,17);
INSERT INTO tableTest VALUES(5,"lena",12,95);
INSERT INTO tableTest VALUES(6,"lucas",18,35);

INSERT INTO tableTest VALUES(7,"erwan",14,25);
INSERT INTO tableTest VALUES(8,"alex",16,99);
INSERT INTO tableTest VALUES(9,"vincent",14,17);
INSERT INTO tableTest VALUES(10,"baptiste",17,17);
INSERT INTO tableTest VALUES(11,"thomas",19,21);
INSERT INTO tableTest VALUES(12,"florian",21,19);
INSERT INTO tableTest VALUES(13,"florent",78,3);
INSERT INTO tableTest VALUES(14,"jurgen",45,45);

INSERT INTO tableTest VALUES(15,"manu",60,5);
INSERT INTO tableTest VALUES(16,"brigitte",120,2);
INSERT INTO tableTest VALUES(17,"angela",18,356);
INSERT INTO tableTest VALUES(18,"peta jensen",28,32);
